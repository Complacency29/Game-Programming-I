using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "State")]
public class State : ScriptableObject
{
    [SerializeField] string nameText;
    [SerializeField] string gameText;
    [SerializeField] State[] otherStates;

    public string GetStoryText()
    {
        return gameText;
    }
    public string GetNameText()
    {
        return nameText;
    }

    public State[] GetOtherStates()
    {
        return otherStates;
    }
}
