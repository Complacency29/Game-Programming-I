using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class MainGame : MonoBehaviour
{
    [SerializeField] Text storyText;
    [SerializeField] Text choiceAText;
    [SerializeField] Text choiceBText;
    [SerializeField] State startState;
    State state;

    private bool gameOver = false;

    private void Start()
    {
        state = startState;
        storyText.text = state.GetStoryText();
    }

    private void Update()
    {
        GameMain();
    }

    //Used to respond to the user input
    private void GameMain()
    {
        if (gameOver)
            return;

        State[] statesArray = state.GetOtherStates();

        if (statesArray.Length == 0)
        {
            gameOver = true;
            //storyText.text = "Game Over.";
            choiceAText.text = "";
            choiceBText.text = "";
            return;
        }
        choiceAText.text = "Left Arrow: " + statesArray[0].GetNameText();
        choiceBText.text = "Right Arrow: " +  statesArray[1].GetNameText();

        if(Input.GetKeyDown(KeyCode.LeftArrow))
        {
            state = statesArray[0];
        }
        else if(Input.GetKeyDown(KeyCode.RightArrow))
        {
            state = statesArray[1];
        }
        storyText.text = state.GetStoryText();
    }
}
